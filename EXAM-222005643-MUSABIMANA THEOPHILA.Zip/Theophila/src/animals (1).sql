-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 19, 2024 at 10:18 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `animals`
--

-- --------------------------------------------------------

--
-- Table structure for table `human`
--

CREATE TABLE `human` (
  `FIRSTNAME` varchar(255) NOT NULL,
  `LASTNAME` varchar(255) NOT NULL,
  `DATE OF BIRTH` varchar(255) NOT NULL,
  `PASSWORD` varchar(255) NOT NULL,
  `USERNAME` varchar(255) NOT NULL,
  `GENDER` varchar(255) NOT NULL,
  `EMAIL` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `human`
--

INSERT INTO `human` (`FIRSTNAME`, `LASTNAME`, `DATE OF BIRTH`, `PASSWORD`, `USERNAME`, `GENDER`, `EMAIL`) VALUES
('THEOPHILA', 'MUSABIMANA', '28/12/2001', 'THEOPHILA123', 'mtheophila', 'FEMALE', 'mtheophila524@gmail.com'),
('MUSABE', 'THEOPHILA', '28/12/2001', 'THEOPHILA', 'mtheophila524@gmail.com', 'FEMALE', 'mtheophila524@gmail.com'),
('', '', '', '', '', 'MALE', ''),
('', '', '', '', '', 'MALE', ''),
('', '', '', '', '', 'MALE', ''),
('', '', '', '', '', 'MALE', ''),
('  MUSABE', '  THEOPHILA', '    28/12/2001', '    ', '   LAULA', 'MALE', '  mtheophila524@gmail.com'),
('NIYOMWUNGERI', 'TURIANE', '13/7/1999', 'shepherd', ' ny', 'FEMALE', ' nshepherd@gmail.com'),
(' KURADUSENGE', ' GILBERT', ' 20/2/1980', 'IAN', 'IAN', 'MALE', ' gilbertkuradusenge@gmail.com'),
('MUGISHA', 'GISELE', '2005', 'gisele', 'gizo', 'FEMALE', 'mugisha@gmail.com'),
('Mutoni', 'Sylivie', '2004', '222005643', 'Theophila', 'FEMALE', 'mutonisylivie@gmail.com');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
